# @family/ui

Shared accessible primitives for every family product (WC-36, WC-DX-7 step 1). Not published to npm: consumers vendor the tarball (`apps/*/vendor/family-ui-<ver>.tgz`, sha256 in the commit), as salesos does for `@family/webhooks`.

- React Aria (`react-aria-components` 1.22.1, `@internationalized/date` 3.12.4): `DatePicker`, `DateRangePicker`, `Calendar`, `RangeCalendar`, `Slider` (`Table` and `Tree` follow in WC-DX-7f).
- Base UI (`@base-ui/react` 1.0.0, the version Timeway coss-ui pins): `Menu`, `Popover`, `Dialog`, `NavigationMenu`, `OTPInput` (built on Base UI `Input`; 1.0.0 has no OTP part).
- `FamilyUIProvider locale="ar-AE"` sets locale and `dir` once for both libraries. Arrows (`Chevron`) are logical, so they mirror in RTL.
- Calendars: `calendar` accepts the 13 ids in `CALENDAR_IDS`; `secondaryCalendar` adds a second day number per cell (Gregorian + Hijri); `highlightRamadan` sets `data-ramadan` on islamic-umalqura month 9. No default per country here (WC-DX-8).
- Styles: `@family/ui/styles.css`, imported after the product's WC-DX-4 token CSS. Colours, radii and fonts come only from token variables (`--color-*`, `--radius-*`, `--font-*`); logical properties only; no `transition: all` (lint rules: WC-DX-7b).

```tsx
import { FamilyUIProvider, DatePicker } from '@family/ui';
import '@family/ui/styles.css';

<FamilyUIProvider locale="ar-SA">
  <DatePicker label="التاريخ" calendar="islamic-umalqura" secondaryCalendar="gregory" highlightRamadan />
</FamilyUIProvider>;
```

Tests (`pnpm test`, vitest + jsdom + Testing Library): one per export (renders, keyboard path, RTL), all 13 calendar ids construct and round-trip, and umalqura 1 Ramadan 1448 = 2027-02-08.
