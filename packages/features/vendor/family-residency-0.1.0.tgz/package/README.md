# @family/residency

Clinic-tenant residency guard for every family product that onboards clinics (Camv, Timeway). WC-31 / WC-29, card WC-PE-15f1. Contract: awasfie/salesos `docs/platform/residency/uae-cell.md` section 7; this package implements it, nothing more. Pure TypeScript, no I/O.

- `requiresResidency(t)`: `vertical` is `clinic` (case-insensitive, trimmed) or `handlesPhi === true`.
- `checkTenantResidency(t, d, registry = RESIDENCY_CELLS)` returns `{ ok: true }` or `{ ok: false, code }`, codes checked in order: `residency_cell_required` (no `residencyCell`), `residency_cell_unknown` (not in the registry), `residency_cell_not_active` (status is not `active`), `residency_cell_mismatch` (`d.cell !== t.residencyCell`).
- `assertTenantResidency(t, d, registry?)` throws `ResidencyError { code, status: 422 }`.
- `deploymentContextFromEnv(env = process.env)` reads `RESIDENCY_CELL`; unset or empty is `null` (the DE plane).
- Non-clinic tenants always pass. With the committed registry (`uae-1`, `ksa-1` both `planned`) every clinic tenant is refused everywhere; `uae-1` flips to `active` only in the provisioning effect PR.
- Run the check at create and at every update that changes `vertical`, `handlesPhi` or `residencyCell`.

```ts
import { assertTenantResidency, deploymentContextFromEnv, ResidencyError } from '@family/residency';

const deployment = deploymentContextFromEnv();
try {
  assertTenantResidency({ vertical, handlesPhi, residencyCell }, deployment);
} catch (e) {
  if (e instanceof ResidencyError) return res.status(e.status).json({ error: e.code });
  throw e;
}
```

Tarball (vendored into camv and timeway): `cd packages/residency && npx tsc -p tsconfig.json && npm pack` -> `family-residency-0.1.0.tgz`. The sha256 is recorded in the PR that ships each version.
