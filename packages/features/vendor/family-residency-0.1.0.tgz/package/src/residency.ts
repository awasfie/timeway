// @family/residency: the clinic-tenant residency guard (WC-31 / WC-29, WC-PE-15f).
// Contract: awasfie/salesos docs/platform/residency/uae-cell.md section 7. Pure TypeScript, no I/O.

export type CellId = 'uae-1' | 'ksa-1';
export type CellStatus = 'planned' | 'active' | 'retired';
export type CellCountry = 'AE' | 'SA';
export interface ResidencyCell {
  country: CellCountry;
  status: CellStatus;
}
export type ResidencyRegistry = Readonly<
  Record<string, Readonly<ResidencyCell>>
>;

// 'uae-1' flips to 'active' only in the provisioning effect PR (uae-cell.md section 9).
export const RESIDENCY_CELLS: Readonly<
  Record<CellId, Readonly<ResidencyCell>>
> = Object.freeze({
  'uae-1': Object.freeze({ country: 'AE', status: 'planned' }),
  'ksa-1': Object.freeze({ country: 'SA', status: 'planned' }),
});

export interface TenantResidencyInput {
  vertical?: string | null;
  handlesPhi?: boolean | null;
  residencyCell?: string | null;
}

/** The deployment's own cell, from env RESIDENCY_CELL; null on the DE plane. */
export interface DeploymentContext {
  cell: string | null;
}

export type ResidencyErrorCode =
  | 'residency_cell_required'
  | 'residency_cell_unknown'
  | 'residency_cell_not_active'
  | 'residency_cell_mismatch';

export type ResidencyCheckResult =
  { ok: true } | { ok: false; code: ResidencyErrorCode };

export class ResidencyError extends Error {
  readonly status = 422 as const;
  constructor(readonly code: ResidencyErrorCode) {
    super(code);
    this.name = 'ResidencyError';
  }
}

/** vertical === 'clinic' (case-insensitive, trimmed) or handlesPhi === true. */
export function requiresResidency(t: TenantResidencyInput): boolean {
  if (t.handlesPhi === true) return true;
  return (
    typeof t.vertical === 'string' &&
    t.vertical.trim().toLowerCase() === 'clinic'
  );
}

export function checkTenantResidency(
  t: TenantResidencyInput,
  d: DeploymentContext,
  registry: ResidencyRegistry = RESIDENCY_CELLS,
): ResidencyCheckResult {
  if (!requiresResidency(t)) return { ok: true };
  const cell = t.residencyCell;
  if (cell === undefined || cell === null || cell === '')
    return { ok: false, code: 'residency_cell_required' };
  if (!Object.prototype.hasOwnProperty.call(registry, cell))
    return { ok: false, code: 'residency_cell_unknown' };
  if (registry[cell].status !== 'active')
    return { ok: false, code: 'residency_cell_not_active' };
  if (d.cell !== cell) return { ok: false, code: 'residency_cell_mismatch' };
  return { ok: true };
}

/** Throws ResidencyError { code, status: 422 } when the check fails. */
export function assertTenantResidency(
  t: TenantResidencyInput,
  d: DeploymentContext,
  registry: ResidencyRegistry = RESIDENCY_CELLS,
): void {
  const r = checkTenantResidency(t, d, registry);
  if (!r.ok) throw new ResidencyError(r.code);
}

/** Reads RESIDENCY_CELL; unset or empty means no cell (null). */
export function deploymentContextFromEnv(
  env: Readonly<Record<string, string | undefined>> = process.env,
): DeploymentContext {
  const v = env.RESIDENCY_CELL;
  return { cell: v === undefined || v === '' ? null : v };
}
