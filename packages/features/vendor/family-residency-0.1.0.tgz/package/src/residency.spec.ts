import { describe, expect, it } from 'vitest';
import {
  RESIDENCY_CELLS,
  ResidencyError,
  assertTenantResidency,
  checkTenantResidency,
  deploymentContextFromEnv,
  requiresResidency,
  type ResidencyRegistry,
} from './index.js';

const DE = { cell: null };
const UAE = { cell: 'uae-1' };
const ACTIVE: ResidencyRegistry = {
  ...RESIDENCY_CELLS,
  'uae-1': { country: 'AE', status: 'active' },
};

describe('@family/residency (uae-cell.md section 7)', () => {
  it('committed registry: both cells planned', () => {
    expect(RESIDENCY_CELLS).toEqual({
      'uae-1': { country: 'AE', status: 'planned' },
      'ksa-1': { country: 'SA', status: 'planned' },
    });
    expect(Object.isFrozen(RESIDENCY_CELLS)).toBe(true);
    expect(Object.isFrozen(RESIDENCY_CELLS['uae-1'])).toBe(true);
  });

  it('requiresResidency: clinic (case-insensitive, trimmed) or handlesPhi === true', () => {
    expect(requiresResidency({ vertical: 'clinic' })).toBe(true);
    expect(requiresResidency({ vertical: '  Clinic ' })).toBe(true);
    expect(requiresResidency({ vertical: 'CLINIC' })).toBe(true);
    expect(requiresResidency({ vertical: 'retail', handlesPhi: true })).toBe(
      true,
    );
    expect(requiresResidency({ handlesPhi: true })).toBe(true);
    expect(requiresResidency({ vertical: 'retail' })).toBe(false);
    expect(requiresResidency({ vertical: 'clinics' })).toBe(false);
    expect(requiresResidency({ vertical: null, handlesPhi: null })).toBe(false);
    expect(requiresResidency({ handlesPhi: false })).toBe(false);
    expect(requiresResidency({})).toBe(false);
  });

  it('non-clinic tenants always pass, whatever the cell or deployment', () => {
    for (const d of [DE, UAE, { cell: 'mars-9' }]) {
      expect(checkTenantResidency({ vertical: 'retail' }, d)).toEqual({
        ok: true,
      });
      expect(
        checkTenantResidency({ vertical: 'retail', residencyCell: 'nope' }, d),
      ).toEqual({ ok: true });
      expect(checkTenantResidency({}, d)).toEqual({ ok: true });
    }
  });

  it('clinic without a cell -> residency_cell_required', () => {
    for (const residencyCell of [undefined, null, '']) {
      expect(
        checkTenantResidency(
          { vertical: 'clinic', residencyCell },
          UAE,
          ACTIVE,
        ),
      ).toEqual({
        ok: false,
        code: 'residency_cell_required',
      });
    }
  });

  it('unknown cell -> residency_cell_unknown (prototype keys are not cells)', () => {
    for (const residencyCell of ['eu-1', 'UAE-1', 'toString', '__proto__']) {
      expect(
        checkTenantResidency(
          { vertical: 'clinic', residencyCell },
          UAE,
          ACTIVE,
        ),
      ).toEqual({
        ok: false,
        code: 'residency_cell_unknown',
      });
    }
  });

  it('planned cell -> residency_cell_not_active; committed registry refuses every clinic everywhere', () => {
    for (const d of [DE, UAE, { cell: 'ksa-1' }]) {
      for (const residencyCell of ['uae-1', 'ksa-1']) {
        expect(
          checkTenantResidency({ vertical: 'clinic', residencyCell }, d),
        ).toEqual({
          ok: false,
          code: 'residency_cell_not_active',
        });
      }
    }
    const retired: ResidencyRegistry = {
      'uae-1': { country: 'AE', status: 'retired' },
    };
    expect(
      checkTenantResidency(
        { vertical: 'clinic', residencyCell: 'uae-1' },
        UAE,
        retired,
      ),
    ).toEqual({
      ok: false,
      code: 'residency_cell_not_active',
    });
  });

  it('active cell, mismatched deployment -> residency_cell_mismatch (no clinic on the DE plane)', () => {
    expect(
      checkTenantResidency(
        { vertical: 'clinic', residencyCell: 'uae-1' },
        DE,
        ACTIVE,
      ),
    ).toEqual({
      ok: false,
      code: 'residency_cell_mismatch',
    });
    expect(
      checkTenantResidency(
        { vertical: 'clinic', residencyCell: 'uae-1' },
        { cell: 'ksa-1' },
        ACTIVE,
      ),
    ).toEqual({
      ok: false,
      code: 'residency_cell_mismatch',
    });
  });

  it('active matching cell -> ok; handlesPhi with any vertical treated as clinic', () => {
    expect(
      checkTenantResidency(
        { vertical: 'clinic', residencyCell: 'uae-1' },
        UAE,
        ACTIVE,
      ),
    ).toEqual({ ok: true });
    expect(
      checkTenantResidency(
        { vertical: 'retail', handlesPhi: true },
        UAE,
        ACTIVE,
      ),
    ).toEqual({
      ok: false,
      code: 'residency_cell_required',
    });
    expect(
      checkTenantResidency(
        { vertical: 'retail', handlesPhi: true, residencyCell: 'uae-1' },
        UAE,
        ACTIVE,
      ),
    ).toEqual({ ok: true });
  });

  it('update that flips a tenant to clinic is refused', () => {
    const before = { vertical: 'retail', residencyCell: null };
    expect(checkTenantResidency(before, DE)).toEqual({ ok: true });
    expect(checkTenantResidency({ ...before, vertical: 'clinic' }, DE)).toEqual(
      {
        ok: false,
        code: 'residency_cell_required',
      },
    );
  });

  it('codes are checked in order: required, unknown, not_active, mismatch', () => {
    // a tenant that would fail every later check reports the first
    expect(checkTenantResidency({ vertical: 'clinic' }, DE)).toMatchObject({
      code: 'residency_cell_required',
    });
    expect(
      checkTenantResidency({ vertical: 'clinic', residencyCell: 'x' }, DE),
    ).toMatchObject({
      code: 'residency_cell_unknown',
    });
    expect(
      checkTenantResidency({ vertical: 'clinic', residencyCell: 'uae-1' }, DE),
    ).toMatchObject({
      code: 'residency_cell_not_active',
    });
  });

  it('assertTenantResidency throws ResidencyError { code, status: 422 }', () => {
    expect(() =>
      assertTenantResidency({ vertical: 'retail' }, DE),
    ).not.toThrow();
    expect(() =>
      assertTenantResidency(
        { vertical: 'clinic', residencyCell: 'uae-1' },
        UAE,
        ACTIVE,
      ),
    ).not.toThrow();
    let err: unknown;
    try {
      assertTenantResidency(
        { vertical: 'clinic', residencyCell: 'uae-1' },
        UAE,
      );
    } catch (e) {
      err = e;
    }
    expect(err).toBeInstanceOf(ResidencyError);
    expect(err).toBeInstanceOf(Error);
    expect(err).toMatchObject({
      code: 'residency_cell_not_active',
      status: 422,
      name: 'ResidencyError',
    });
  });

  it('deploymentContextFromEnv reads RESIDENCY_CELL; unset/empty -> null', () => {
    expect(deploymentContextFromEnv({})).toEqual({ cell: null });
    expect(deploymentContextFromEnv({ RESIDENCY_CELL: '' })).toEqual({
      cell: null,
    });
    expect(deploymentContextFromEnv({ RESIDENCY_CELL: 'uae-1' })).toEqual({
      cell: 'uae-1',
    });
    const prev = process.env.RESIDENCY_CELL;
    try {
      process.env.RESIDENCY_CELL = 'ksa-1';
      expect(deploymentContextFromEnv()).toEqual({ cell: 'ksa-1' });
      delete process.env.RESIDENCY_CELL;
      expect(deploymentContextFromEnv()).toEqual({ cell: null });
    } finally {
      if (prev === undefined) delete process.env.RESIDENCY_CELL;
      else process.env.RESIDENCY_CELL = prev;
    }
  });
});
