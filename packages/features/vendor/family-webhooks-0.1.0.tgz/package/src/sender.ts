/**
 * @family/webhooks sender: signed delivery with exponential backoff + full
 * jitter; HTTP 410 Gone disables the endpoint and stops retrying.
 *
 * Persistence is the caller's: the sender reports a disable through
 * `EndpointStore.disable` and never mutates anything else. Durable retry
 * across process restarts belongs to the outbox (@family/outbox); this
 * loop covers one in-process delivery.
 */
import { generateMessageId, signHeaders } from './signature.js';

export interface WebhookEndpoint {
  id: string;
  url: string;
  /** Active secrets, newest first; every one signs (rotation window). */
  secrets: readonly string[];
  disabled?: boolean;
}

export interface EndpointStore {
  disable(endpointId: string, reason: string): Promise<void>;
}

export interface RetryPolicy {
  /** Total attempts including the first. Default 8. */
  maxAttempts: number;
  /** Delay before attempt 2, ms. Default 5 000. */
  baseDelayMs: number;
  /** Growth per attempt. Default 4. */
  factor: number;
  /** Ceiling per wait, ms. Default 10 h. */
  maxDelayMs: number;
  /** Per-attempt timeout, ms. Default 15 000. */
  timeoutMs: number;
}

export const DEFAULT_RETRY_POLICY: RetryPolicy = {
  maxAttempts: 8,
  baseDelayMs: 5_000,
  factor: 4,
  maxDelayMs: 10 * 60 * 60 * 1000,
  timeoutMs: 15_000,
};

/**
 * Full-jitter backoff (AWS architecture blog): uniform in [cap/2, cap]
 * where cap = min(maxDelay, base * factor^(attempt-1)). The lower half is
 * kept so retries never collapse to ~0 ms.
 * `attempt` is the number of the attempt that just failed (1-based).
 */
export function backoffDelay(attempt: number, policy: RetryPolicy = DEFAULT_RETRY_POLICY, random: () => number = Math.random): number {
  const cap = Math.min(policy.maxDelayMs, policy.baseDelayMs * Math.pow(policy.factor, attempt - 1));
  return Math.floor(cap / 2 + random() * (cap / 2));
}

export type DeliveryOutcome =
  | { status: 'delivered'; attempts: number; httpStatus: number; messageId: string }
  | { status: 'disabled'; attempts: number; httpStatus: 410; messageId: string }
  | { status: 'failed'; attempts: number; httpStatus: number | null; error: string; messageId: string }
  | { status: 'skipped'; attempts: 0; messageId: string };

export interface SenderOptions {
  store: EndpointStore;
  policy?: Partial<RetryPolicy>;
  fetch?: typeof fetch;
  sleep?: (ms: number) => Promise<void>;
  random?: () => number;
  now?: () => number;
  userAgent?: string;
}

export interface WebhookMessage {
  /** Stable across retries; generated when absent. */
  id?: string;
  /** Exact bytes sent and signed. */
  body: string;
}

export class WebhookSender {
  private readonly policy: RetryPolicy;
  private readonly fetchImpl: typeof fetch;
  private readonly sleep: (ms: number) => Promise<void>;
  private readonly random: () => number;
  private readonly now: () => number;

  constructor(private readonly opts: SenderOptions) {
    this.policy = { ...DEFAULT_RETRY_POLICY, ...opts.policy };
    this.fetchImpl = opts.fetch ?? fetch;
    this.sleep = opts.sleep ?? ((ms) => new Promise((r) => setTimeout(r, ms)));
    this.random = opts.random ?? Math.random;
    this.now = opts.now ?? Date.now;
  }

  async deliver(endpoint: WebhookEndpoint, message: WebhookMessage): Promise<DeliveryOutcome> {
    const messageId = message.id ?? generateMessageId();
    if (endpoint.disabled) return { status: 'skipped', attempts: 0, messageId };

    let lastStatus: number | null = null;
    let lastError = '';
    for (let attempt = 1; attempt <= this.policy.maxAttempts; attempt++) {
      // Re-signed every attempt: the timestamp must be fresh or the receiver's
      // 5-minute tolerance rejects late retries. The id stays the same so the
      // receiver can dedupe.
      const headers = signHeaders(endpoint.secrets, message.body, {
        id: messageId,
        timestamp: Math.floor(this.now() / 1000),
      });
      try {
        const res = await this.fetchImpl(endpoint.url, {
          method: 'POST',
          headers: {
            'content-type': 'application/json',
            'user-agent': this.opts.userAgent ?? 'family-webhooks/0.1',
            ...headers,
          },
          body: message.body,
          redirect: 'manual',
          signal: AbortSignal.timeout(this.policy.timeoutMs),
        });
        lastStatus = res.status;
        await res.body?.cancel().catch(() => undefined);
        if (res.status >= 200 && res.status < 300) {
          return { status: 'delivered', attempts: attempt, httpStatus: res.status, messageId };
        }
        if (res.status === 410) {
          await this.opts.store.disable(endpoint.id, 'http_410_gone');
          return { status: 'disabled', attempts: attempt, httpStatus: 410, messageId };
        }
        lastError = `http_${res.status}`;
      } catch (err) {
        lastStatus = null;
        lastError = err instanceof Error ? err.name : 'network_error';
      }
      if (attempt < this.policy.maxAttempts) await this.sleep(backoffDelay(attempt, this.policy, this.random));
    }
    return { status: 'failed', attempts: this.policy.maxAttempts, httpStatus: lastStatus, error: lastError, messageId };
  }
}
