/**
 * @family/webhooks — Standard Webhooks (https://www.standardwebhooks.com)
 * signer and verifier. WC-31 WC-PE-14 step 6; proof CC-95 clause 3.
 *
 * Wire format (spec v1):
 *   webhook-id:        unique message id, stable across retries
 *   webhook-timestamp: integer unix seconds
 *   webhook-signature: space-separated list of `v1,<base64 HMAC-SHA256>`
 *   signed content:    `${id}.${timestamp}.${rawBody}`
 *
 * Secrets: `whsec_<base64>` decoding to 24..64 bytes. Values are read from
 * env/Infisical by name by the caller; this module never logs them.
 *
 * Rotation: the sender signs with every active secret (one `v1,` entry per
 * secret); the receiver accepts a message when any configured secret
 * matches any entry. Both sides therefore hold [current, previous] during a
 * rotation window and no delivery drops.
 */
import { createHmac, randomBytes, timingSafeEqual } from 'node:crypto';

export const SECRET_PREFIX = 'whsec_';
export const SECRET_MIN_BYTES = 24;
export const SECRET_MAX_BYTES = 64;
/** Default replay window, seconds, both directions (spec recommendation: 5 min). */
export const DEFAULT_TOLERANCE_SECONDS = 5 * 60;

export const HEADER_ID = 'webhook-id';
export const HEADER_TIMESTAMP = 'webhook-timestamp';
export const HEADER_SIGNATURE = 'webhook-signature';

export type WebhookHeaders = {
  'webhook-id': string;
  'webhook-timestamp': string;
  'webhook-signature': string;
};

export type WebhookErrorCode =
  | 'invalid_secret'
  | 'missing_headers'
  | 'invalid_timestamp'
  | 'timestamp_too_old'
  | 'timestamp_too_new'
  | 'no_matching_signature';

export class WebhookVerificationError extends Error {
  constructor(
    readonly code: WebhookErrorCode,
    message: string,
  ) {
    super(message);
    this.name = 'WebhookVerificationError';
  }
}

/** Decode and validate a `whsec_` secret. Throws on wrong prefix or size. */
export function decodeSecret(secret: string): Buffer {
  if (typeof secret !== 'string' || !secret.startsWith(SECRET_PREFIX)) {
    throw new WebhookVerificationError('invalid_secret', `secret must start with ${SECRET_PREFIX}`);
  }
  const b64 = secret.slice(SECRET_PREFIX.length);
  if (!/^[A-Za-z0-9+/]+={0,2}$/.test(b64)) {
    throw new WebhookVerificationError('invalid_secret', 'secret is not valid base64');
  }
  const key = Buffer.from(b64, 'base64');
  if (key.length < SECRET_MIN_BYTES || key.length > SECRET_MAX_BYTES) {
    throw new WebhookVerificationError(
      'invalid_secret',
      `secret must decode to ${SECRET_MIN_BYTES}-${SECRET_MAX_BYTES} bytes (got ${key.length})`,
    );
  }
  return key;
}

/** New random secret, default 32 bytes. */
export function generateSecret(bytes = 32): string {
  if (!Number.isInteger(bytes) || bytes < SECRET_MIN_BYTES || bytes > SECRET_MAX_BYTES) {
    throw new RangeError(`secret size must be ${SECRET_MIN_BYTES}-${SECRET_MAX_BYTES} bytes`);
  }
  return SECRET_PREFIX + randomBytes(bytes).toString('base64');
}

/** New message id (`msg_` + 24 random bytes, url-safe). */
export function generateMessageId(): string {
  return 'msg_' + randomBytes(18).toString('base64url');
}

function toSecretList(secrets: string | readonly string[]): Buffer[] {
  const list = typeof secrets === 'string' ? [secrets] : [...secrets];
  const keys = list.filter((s) => s !== undefined && s !== null && s !== '').map(decodeSecret);
  if (keys.length === 0) throw new WebhookVerificationError('invalid_secret', 'no secret configured');
  return keys;
}

function hmac(key: Buffer, id: string, timestamp: number, payload: string | Buffer): Buffer {
  return createHmac('sha256', key)
    .update(`${id}.${timestamp}.`)
    .update(typeof payload === 'string' ? Buffer.from(payload, 'utf8') : payload)
    .digest();
}

/** `v1,<base64>` signature list for one message, one entry per active secret. */
export function sign(
  secrets: string | readonly string[],
  id: string,
  timestampSeconds: number,
  payload: string | Buffer,
): string {
  if (!id) throw new Error('message id is required');
  if (!Number.isInteger(timestampSeconds)) throw new Error('timestamp must be integer unix seconds');
  return toSecretList(secrets)
    .map((key) => `v1,${hmac(key, id, timestampSeconds, payload).toString('base64')}`)
    .join(' ');
}

export interface SignOptions {
  id?: string;
  /** Unix seconds; defaults to now. */
  timestamp?: number;
}

/** Full header set for an outbound delivery. */
export function signHeaders(
  secrets: string | readonly string[],
  payload: string | Buffer,
  opts: SignOptions = {},
): WebhookHeaders {
  const id = opts.id ?? generateMessageId();
  const timestamp = opts.timestamp ?? Math.floor(Date.now() / 1000);
  return {
    [HEADER_ID]: id,
    [HEADER_TIMESTAMP]: String(timestamp),
    [HEADER_SIGNATURE]: sign(secrets, id, timestamp, payload),
  } as WebhookHeaders;
}

export interface VerifyOptions {
  /** Seconds; default 300. Applies to both past and future skew. */
  toleranceSeconds?: number;
  /** Clock override (ms), for tests. */
  now?: () => number;
}

type HeaderBag = Record<string, string | string[] | undefined> | Headers;

function header(headers: HeaderBag, name: string): string | undefined {
  if (typeof (headers as Headers).get === 'function') return (headers as Headers).get(name) ?? undefined;
  const bag = headers as Record<string, string | string[] | undefined>;
  const direct = bag[name] ?? bag[Object.keys(bag).find((k) => k.toLowerCase() === name) ?? ''];
  return Array.isArray(direct) ? direct[0] : direct;
}

export interface VerifiedMessage {
  id: string;
  timestamp: number;
}

/**
 * Verify a received message against one or more secrets (rotation).
 * `payload` must be the exact raw body bytes. Throws WebhookVerificationError.
 */
export function verify(
  secrets: string | readonly string[],
  payload: string | Buffer,
  headers: HeaderBag,
  opts: VerifyOptions = {},
): VerifiedMessage {
  const keys = toSecretList(secrets);
  const id = header(headers, HEADER_ID);
  const ts = header(headers, HEADER_TIMESTAMP);
  const sigHeader = header(headers, HEADER_SIGNATURE);
  if (!id || !ts || !sigHeader) {
    throw new WebhookVerificationError('missing_headers', 'missing webhook-id, webhook-timestamp or webhook-signature');
  }
  if (!/^\d{1,12}$/.test(ts)) throw new WebhookVerificationError('invalid_timestamp', 'invalid webhook-timestamp');
  const timestamp = Number(ts);
  const tolerance = opts.toleranceSeconds ?? DEFAULT_TOLERANCE_SECONDS;
  const nowSec = Math.floor((opts.now ?? Date.now)() / 1000);
  if (nowSec - timestamp > tolerance) {
    throw new WebhookVerificationError('timestamp_too_old', 'message timestamp too old');
  }
  if (timestamp - nowSec > tolerance) {
    throw new WebhookVerificationError('timestamp_too_new', 'message timestamp too new');
  }

  const candidates: Buffer[] = [];
  for (const part of sigHeader.split(' ')) {
    const comma = part.indexOf(',');
    if (comma < 0 || part.slice(0, comma) !== 'v1') continue;
    candidates.push(Buffer.from(part.slice(comma + 1), 'base64'));
  }

  // Constant-time per comparison; every (key, candidate) pair is checked so
  // the timing does not reveal which key or entry matched.
  let ok = false;
  for (const key of keys) {
    const expected = hmac(key, id, timestamp, payload);
    for (const cand of candidates) {
      if (cand.length === expected.length && timingSafeEqual(cand, expected)) ok = true;
    }
  }
  if (!ok) throw new WebhookVerificationError('no_matching_signature', 'no matching signature');
  return { id, timestamp };
}
