import { describe, expect, it, vi } from 'vitest';
import { Webhook, WebhookVerificationError as RefError } from 'standardwebhooks';
import {
  DEFAULT_RETRY_POLICY,
  WebhookSender,
  WebhookVerificationError,
  backoffDelay,
  decodeSecret,
  generateSecret,
  sign,
  signHeaders,
  verify,
} from './index.js';

const T0 = 1_792_000_000; // fixed unix seconds
const body = JSON.stringify({ type: 'subscription.updated', timestamp: '2026-10-15T00:00:00Z', data: { org: 'org_1' } });

describe('@family/webhooks signature (Standard Webhooks, CC-95 clause 3)', () => {
  it('is byte-identical to the reference signer', () => {
    const secret = generateSecret();
    const ref = new Webhook(secret);
    expect(sign(secret, 'msg_1', T0, body)).toBe(ref.sign('msg_1', new Date(T0 * 1000), body));
  });

  it('every signature we emit verifies with the reference verifier', () => {
    for (const bytes of [24, 32, 64]) {
      const secret = generateSecret(bytes);
      const headers = signHeaders(secret, body);
      expect(new Webhook(secret).verify(body, { ...headers })).toEqual(JSON.parse(body));
    }
  });

  it('accepts what the reference signer emits', () => {
    const secret = generateSecret();
    const now = Date.now();
    const ts = Math.floor(now / 1000);
    const sig = new Webhook(secret).sign('msg_ref', new Date(ts * 1000), body);
    const headers = { 'webhook-id': 'msg_ref', 'webhook-timestamp': String(ts), 'webhook-signature': sig };
    expect(verify(secret, body, headers, { now: () => now })).toEqual({ id: 'msg_ref', timestamp: ts });
  });

  it('replay at +6 min is rejected by us and by the reference verifier', () => {
    const secret = generateSecret();
    const sentAt = Math.floor(Date.now() / 1000) - 6 * 60;
    const headers = signHeaders(secret, body, { id: 'msg_replay', timestamp: sentAt });
    expect(() => verify(secret, body, headers)).toThrow(
      expect.objectContaining({ code: 'timestamp_too_old' }),
    );
    expect(() => new Webhook(secret).verify(body, { ...headers })).toThrow(RefError);
  });

  it('5-minute window: +4m59s accepted, +5m01s rejected, future skew bounded', () => {
    const secret = generateSecret();
    const headers = signHeaders(secret, body, { id: 'msg_w', timestamp: T0 });
    expect(() => verify(secret, body, headers, { now: () => (T0 + 299) * 1000 })).not.toThrow();
    expect(() => verify(secret, body, headers, { now: () => (T0 + 301) * 1000 })).toThrow(/too old/);
    expect(() => verify(secret, body, headers, { now: () => (T0 - 301) * 1000 })).toThrow(/too new/);
  });

  it('rejects a tampered body, a wrong secret, a wrong id and a non-v1 scheme', () => {
    const secret = generateSecret();
    const now = () => T0 * 1000;
    const h = signHeaders(secret, body, { id: 'msg_t', timestamp: T0 });
    expect(() => verify(secret, body + ' ', h, { now })).toThrow(WebhookVerificationError);
    expect(() => verify(generateSecret(), body, h, { now })).toThrow(/no matching signature/);
    expect(() => verify(secret, body, { ...h, 'webhook-id': 'msg_other' }, { now })).toThrow(/no matching/);
    const v2 = h['webhook-signature'].replace('v1,', 'v2,');
    expect(() => verify(secret, body, { ...h, 'webhook-signature': v2 }, { now })).toThrow(/no matching/);
    // wrong-length candidate must not throw from timingSafeEqual
    expect(() => verify(secret, body, { ...h, 'webhook-signature': 'v1,AAAA' }, { now })).toThrow(/no matching/);
  });

  it('missing headers and malformed timestamps are rejected', () => {
    const secret = generateSecret();
    expect(() => verify(secret, body, {})).toThrow(expect.objectContaining({ code: 'missing_headers' }));
    const h = signHeaders(secret, body);
    expect(() => verify(secret, body, { ...h, 'webhook-timestamp': '12.5' })).toThrow(
      expect.objectContaining({ code: 'invalid_timestamp' }),
    );
  });

  it('reads headers case-insensitively from a plain object and from a Headers instance', () => {
    const secret = generateSecret();
    const h = signHeaders(secret, body);
    const upper = { 'Webhook-Id': h['webhook-id'], 'Webhook-Timestamp': h['webhook-timestamp'], 'Webhook-Signature': h['webhook-signature'] };
    expect(() => verify(secret, body, upper)).not.toThrow();
    expect(() => verify(secret, body, new Headers({ ...h }))).not.toThrow();
  });

  it('dual secrets: sender signs with both, receiver on either old or new verifies; reference agrees', () => {
    const oldS = generateSecret();
    const newS = generateSecret();
    const h = signHeaders([newS, oldS], body);
    expect(h['webhook-signature'].split(' ')).toHaveLength(2);
    expect(() => verify(oldS, body, h)).not.toThrow();
    expect(() => verify(newS, body, h)).not.toThrow();
    expect(() => new Webhook(oldS).verify(body, { ...h })).not.toThrow();
    expect(() => new Webhook(newS).verify(body, { ...h })).not.toThrow();
    // receiver holding [new, old] accepts a sender still on old only
    expect(() => verify([newS, oldS], body, signHeaders(oldS, body))).not.toThrow();
  });

  it('secret validation: whsec_ prefix, 24-64 bytes', () => {
    const b = (n: number) => 'whsec_' + Buffer.alloc(n, 7).toString('base64');
    expect(decodeSecret(b(24))).toHaveLength(24);
    expect(decodeSecret(b(64))).toHaveLength(64);
    expect(() => decodeSecret(b(23))).toThrow(/24-64 bytes/);
    expect(() => decodeSecret(b(65))).toThrow(/24-64 bytes/);
    expect(() => decodeSecret(Buffer.alloc(32).toString('base64'))).toThrow(/whsec_/);
    expect(() => decodeSecret('whsec_not base64!')).toThrow(/base64/);
    expect(() => generateSecret(16)).toThrow(RangeError);
    expect(() => sign([], 'm', T0, body)).toThrow(/no secret/);
  });
});

describe('@family/webhooks sender', () => {
  const endpoint = (secrets: string[]) => ({ id: 'ep_1', url: 'https://receiver.test/hook', secrets });
  const res = (status: number) => new Response(status === 204 ? null : 'x', { status });

  it('backoff is exponential with jitter in [cap/2, cap] and capped', () => {
    const p = DEFAULT_RETRY_POLICY;
    expect(backoffDelay(1, p, () => 0)).toBe(2_500);
    expect(backoffDelay(1, p, () => 0.999999)).toBeLessThanOrEqual(5_000);
    expect(backoffDelay(2, p, () => 0)).toBe(10_000);
    expect(backoffDelay(3, p, () => 0)).toBe(40_000);
    expect(backoffDelay(20, p, () => 1)).toBe(p.maxDelayMs);
    const samples = new Set(Array.from({ length: 50 }, () => backoffDelay(4, p)));
    expect(samples.size).toBeGreaterThan(1);
  });

  it('retries on 5xx and network error, keeps the id, re-signs with a fresh timestamp, delivers on 2xx', async () => {
    const secret = generateSecret();
    let clock = T0 * 1000;
    const seen: Headers[] = [];
    const fetchMock = vi.fn(async (_url: unknown, init?: RequestInit) => {
      seen.push(new Headers(init!.headers));
      if (seen.length === 1) return res(503);
      if (seen.length === 2) throw new TypeError('fetch failed');
      return res(204);
    });
    const sleeps: number[] = [];
    const sender = new WebhookSender({
      store: { disable: vi.fn() },
      fetch: fetchMock as unknown as typeof fetch,
      sleep: async (ms) => {
        sleeps.push(ms);
        clock += ms;
      },
      now: () => clock,
      random: () => 0,
    });
    const out = await sender.deliver(endpoint([secret]), { id: 'msg_r', body });
    expect(out).toMatchObject({ status: 'delivered', attempts: 3, httpStatus: 204, messageId: 'msg_r' });
    expect(sleeps).toEqual([2_500, 10_000]);
    expect(seen.map((h) => h.get('webhook-id'))).toEqual(['msg_r', 'msg_r', 'msg_r']);
    expect(seen[2].get('webhook-timestamp')).toBe(String(T0 + 12));
    // the last delivery verifies with the reference verifier at its send time
    const last = Object.fromEntries(seen[2].entries());
    expect(() => verify(secret, body, last, { now: () => clock })).not.toThrow();
  });

  it('410 Gone disables the endpoint and stops retrying', async () => {
    const disable = vi.fn(async () => undefined);
    const fetchMock = vi.fn(async () => res(410));
    const sender = new WebhookSender({ store: { disable }, fetch: fetchMock as unknown as typeof fetch, sleep: async () => {} });
    const out = await sender.deliver(endpoint([generateSecret()]), { body });
    expect(out).toMatchObject({ status: 'disabled', attempts: 1, httpStatus: 410 });
    expect(fetchMock).toHaveBeenCalledTimes(1);
    expect(disable).toHaveBeenCalledWith('ep_1', 'http_410_gone');
  });

  it('gives up after maxAttempts and skips a disabled endpoint', async () => {
    const fetchMock = vi.fn(async () => res(500));
    const sender = new WebhookSender({
      store: { disable: vi.fn() },
      fetch: fetchMock as unknown as typeof fetch,
      sleep: async () => {},
      policy: { maxAttempts: 3 },
    });
    expect(await sender.deliver(endpoint([generateSecret()]), { body })).toMatchObject({ status: 'failed', attempts: 3, httpStatus: 500, error: 'http_500' });
    expect(fetchMock).toHaveBeenCalledTimes(3);
    const skipped = await sender.deliver({ ...endpoint([generateSecret()]), disabled: true }, { body });
    expect(skipped.status).toBe('skipped');
    expect(fetchMock).toHaveBeenCalledTimes(3);
  });

  it('end to end over real HTTP: reference verifier on the receiver side accepts the delivery', async () => {
    const { createServer } = await import('node:http');
    const secret = generateSecret();
    const ref = new Webhook(secret);
    let verified: unknown = null;
    const server = createServer((req, resp) => {
      const chunks: Buffer[] = [];
      req.on('data', (c: Buffer) => chunks.push(c));
      req.on('end', () => {
        try {
          verified = ref.verify(Buffer.concat(chunks).toString('utf8'), req.headers as Record<string, string>);
          resp.statusCode = 200;
        } catch {
          resp.statusCode = 401;
        }
        resp.end();
      });
    });
    await new Promise<void>((r) => server.listen(0, '127.0.0.1', r));
    const { port } = server.address() as { port: number };
    try {
      const sender = new WebhookSender({ store: { disable: vi.fn() } });
      const out = await sender.deliver({ id: 'ep_live', url: `http://127.0.0.1:${port}/hook`, secrets: [secret] }, { body });
      expect(out).toMatchObject({ status: 'delivered', httpStatus: 200, attempts: 1 });
      expect(verified).toEqual(JSON.parse(body));
    } finally {
      server.close();
    }
  });
});
