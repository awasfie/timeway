# @family/webhooks

Standard Webhooks (https://www.standardwebhooks.com) signer, verifier and sender for every family product. WC-31 WC-PE-14 step 6; proof clause 3 of CC-95.

- Headers: `webhook-id`, `webhook-timestamp` (unix seconds), `webhook-signature` (`v1,<base64 HMAC-SHA256>` entries, space-separated). Signed content: `${id}.${timestamp}.${rawBody}`.
- Secrets: `whsec_<base64>`, decoding to 24-64 bytes. Read from Infisical / Coolify env by name; never logged.
- Tolerance: 5 minutes each way; a replay at +6 min fails with `timestamp_too_old`.
- Compare: `crypto.timingSafeEqual` against every (secret, signature) pair.
- Rotation: the sender signs with every active secret; the receiver accepts any configured secret. Hold `[new, old]` on both sides for the window, then drop `old`.
- Sender: exponential backoff (5 s x 4^n, capped at 10 h, 8 attempts) with jitter in [cap/2, cap]; the id stays the same on every retry and the signature is redone with a fresh timestamp; HTTP 410 calls `EndpointStore.disable(id, 'http_410_gone')` and stops.

```ts
import { signHeaders, verify, WebhookSender } from '@family/webhooks';

// receiver: raw body bytes, never the re-serialised JSON
verify([process.env.WEBHOOK_SECRET!, process.env.WEBHOOK_SECRET_PREVIOUS ?? ''], rawBody, req.headers);

// sender
await new WebhookSender({ store }).deliver({ id, url, secrets: [current, previous] }, { body: JSON.stringify(event) });
```

Tests (`src/webhooks.spec.ts`) check output against the reference `standardwebhooks` npm package (dev dependency only): the signatures match byte for byte, and each side verifies the other's output, the +6 min replay, the dual secrets and a real HTTP delivery.
