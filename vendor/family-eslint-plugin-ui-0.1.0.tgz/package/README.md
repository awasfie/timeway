# @family/eslint-plugin-ui

WC-DX-7 lint bans for the family products (Passport, Timeway, salesos, rsdeals). ESLint 8 `.eslintrc` and flat config, plus two dependency-free bins.

## Rules (all `error` in `recommended`)

| Rule | Bans | Fix |
|---|---|---|
| `no-physical-direction` | `ml/mr/pl/pr-*`, `left/right-*`, `text-left/right`, `rounded-l/r/tl/tr/bl/br*`, `border-l/r*`, `scroll-ml/mr/pl/pr-*` (with variants, `!`, `-`, arbitrary values) in `className`/`class`/`cn`/`clsx`/`cva`/`cx`/`twMerge`/`tv` | autofix to `ms/me/ps/pe/start/end/text-start/end/rounded-s/e/ss/se/es/ee/border-s/e`; `left-1/2 -translate-x-1/2` is reported without a fix |
| `no-raw-hex` | hex in class arbitrary values (`bg-[#..]`), JSX `style` objects, colour props (`fill`, `stroke`, `stopColor`, ...) | options `styleProps`, `tokenFiles` (token files exempt) |
| `no-transition-all` | `transition-all`, `transition: all`, `transitionProperty: all` | — |
| `no-italic-rtl` | `italic` class, `fontStyle: italic/oblique` | use `latin-italic` (import `@family/eslint-plugin-ui/css/latin-italic.css`; no-op under `[dir=rtl]`/`:lang(ar)`) |
| `require-bidi-on-mixed-fields` | JSX children whose identifier/member/callee/argument matches `/(email\|phone\|url\|price\|amount\|currency\|currencyCode\|uid\|orderId\|invoiceId\|username)$/i` without `<bdi>` (or `Bidi`/`Ltr` component) or a parent `dir="auto"`/`"ltr"` | options `fields`, `components` |
| `no-unallowlisted-disable` | `eslint-disable*` naming a `@family/ui/*` rule, or blanket, without `-- <reason>` starting with an allowlisted word (`chevron`, `arrow`, `slide-in`, `sheet`, `drawer`, `gradient`) | option `reasons` |

## Exception policy

A physical class is allowed only as an `rtl:`/`ltr:` pair, and only in files or components whose name matches `allowRtlVariant` (default `chevron, arrow, sheet, drawer, slide, gradient`; set per rule option or `settings["@family/ui"].allowRtlVariant`). Run ESLint with `--report-unused-disable-directives`, and run `family-lint-disables <src>` in CI: it reads raw source, so a blanket disable cannot silence it.

## Use

```js
// .eslintrc.cjs (ESLint 8)
module.exports = { extends: ["plugin:@family/ui/recommended"] };

// eslint.config.js (flat)
const ui = require("@family/eslint-plugin-ui");
module.exports = [ui.configs["flat/recommended"]];
```

```sh
family-css-lint [--json] [--token-files re,re] [--allow re,re] src/
family-lint-disables [--reasons a,b] src/
```

`family-css-lint` flags `margin/padding/scroll-margin/scroll-padding/border-left|right`, `left:`/`right:`, physical corner radii, `text-align`/`float`/`clear: left|right`, raw hex outside token files (`tokens`, `brand-tokens`, `*theme.css`), `transition: all`, and `font-style: italic|oblique` under `[dir=rtl]`, `:dir(rtl)` or `:lang(ar)`. `[dir=rtl]`/`[dir=ltr]`-scoped physical properties are allowed in allowlisted files only.

Consumers vendor the tarball (`pnpm pack`) like `@family/webhooks`; the CI step prints its sha256.
