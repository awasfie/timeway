"use strict";
const pkg = require("./package.json");

const rules = {
  "no-physical-direction": require("./lib/rules/no-physical-direction"),
  "no-raw-hex": require("./lib/rules/no-raw-hex"),
  "no-transition-all": require("./lib/rules/no-transition-all"),
  "no-italic-rtl": require("./lib/rules/no-italic-rtl"),
  "require-bidi-on-mixed-fields": require("./lib/rules/require-bidi-on-mixed-fields"),
  "no-unallowlisted-disable": require("./lib/rules/no-unallowlisted-disable"),
};

const ruleLevels = Object.fromEntries(Object.keys(rules).map((r) => [`@family/ui/${r}`, "error"]));

const plugin = {
  meta: { name: pkg.name, version: pkg.version },
  rules,
  configs: {},
};

// ESLint 8 .eslintrc (Timeway, salesos).
plugin.configs.recommended = {
  plugins: ["@family/ui"],
  parserOptions: { ecmaFeatures: { jsx: true } },
  reportUnusedDisableDirectives: true,
  rules: ruleLevels,
};

// Flat config (eslint.config.js).
plugin.configs["flat/recommended"] = {
  plugins: { "@family/ui": plugin },
  languageOptions: { parserOptions: { ecmaFeatures: { jsx: true } } },
  linterOptions: { reportUnusedDisableDirectives: "error" },
  rules: ruleLevels,
};

module.exports = plugin;
